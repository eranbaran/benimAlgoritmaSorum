
package idmanprogramı;

import java.util.Scanner;

public class IdmanProgramı {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("İdman programına hoşgeldiniz..");
        String hareketler = "Burpee\n"
                +   "Situp\n"
                + "Squat\n"
                + "Pushup ";
        System.out.println(hareketler);
        System.out.println("Bir idman oluşturun..");
        
        System.out.println("Lütfen Burpee sayısını giriniz; ");
        int BurpeeSayi = input.nextInt();
        System.out.println("Lütfen Situp sayısını giriniz; ");
        int SitupSayi = input.nextInt();
        System.out.println("Lütfen Squat sayısını giriniz; ");
        int SquatSayi = input.nextInt();
        System.out.println("Lütfen Pushup sayısını giriniz; ");
        int PushupSayi = input.nextInt();
        input.nextLine();
        
        İdman idman = new İdman(BurpeeSayi,PushupSayi,SquatSayi,SitupSayi);
        
        System.out.println("İdman başlıyor...");
        
        while(idman.İdmanBittiMi()==false){
            System.out.print("Hangi hareketi yapıcaksınız? (Burpee,Situp,Squat,Pushup)");
            String hareket = input.nextLine();
            System.out.print("Bu hareketi kaç defa yapıcaksınız? ");
            int sayi = input.nextInt();
            input.nextLine();
            idman.hareketYap(hareket, sayi);
        }
    
    }
    
}
